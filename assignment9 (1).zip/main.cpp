/*************************************************************************
 * AUTHOR          : Yuxiang Liu
 * ASSIGNMENT#9    : Linked List - Templates and Exceptions
 * CLASS           : CS3A
 * SECTION         : MW: 8:45AM - 10:10AM
 *                 : TTH: 7:30AM - 9:35AM
 * Due Date        : 5/25/2015
 *************************************************************************/
#include "LinkedList.h"
#include "LinkedList.h" // to test #ifndef
#include <iostream>
using namespace std;

/**************************************************************************
 *Linked List - Templates and Exceptions
 *_________________________________________________________________________
 * Description
 *  This is used to test the linked list and exception
 * ________________________________________________________________________
 * INPUT:
 *      nothing
 * OUTPUT:
 *      integer list
 *      character list
 *      string list
 *
 *************************************************************************/


int main()
{
    //////////////////////Test for integer//////////////////
    LinkedList<int> L1;
    cout<<"test for get front"<<endl;
    try{
        cout<<L1.front()<<endl;
    }catch(ListEmpty e){
        cout<<e.what();
    }

    cout<<"\n test for get back"<<endl;
    try{
        cout<<L1.back()<<endl;
    }catch(ListEmpty e){
        cout<<e.what();
    }

    cout<<"\n test for pop front"<<endl;
    try{
        L1.pop_front();
    }catch(ListEmpty e){
        cout<<e.what();
    }

    cout<<"\n test for push back "<<endl;
    for(int i = 0 ; i< 10 ; i++){
        L1.push_back(i);
    }
    L1.display();
    cout<<"\n test for push front "<<endl;
    for(int i = 0; i< 20 ; i++){
        L1.push_front(i);
    }
    L1.display();


    cout<<"\n test for remove duplicate "<<endl;
    L1.remove_duplicates();
    L1.display();

    cout<<"\n test for sort"<<endl;
    L1.select_sort();
    L1.display();

    cout<<"\n test for insert a number at back"<<endl;
    L1.insert_sorted(30);
    L1.display();
    cout<<"\n test for insert a number at front"<<endl;
    L1.insert_sorted(-111);
    L1.display();
    cout<<"\n test for insert a number at middle"<<endl;
    L1.insert_sorted(3);
    L1.display();

    LinkedList<int> L2(L1);
    cout<<"\n test for assign constructor "<<endl;
    L2.display();
    cout<<"\n test for assign operator "<<endl;
    LinkedList<int> L3;
    L3 = L2;
    L3.display();

    cout<<"\n get front and pop front"<<endl;

        for(int i = 0 ;i < 25 ; i ++){
         try{
            cout<<i<<"   "<<L1.front()<<endl;
            L1.pop_front();
           }catch(ListEmpty e){
                cout<<e.what();
           }
        }

    //////////////////////Test for character//////////////////
    cout<<"\n**********************CHAR**************"<<endl;
    LinkedList<char> cL1;
    cout<<"test for get front"<<endl;
    try{
        cout<<cL1.front()<<endl;
    }catch(ListEmpty e){
        cout<<e.what();
    }

    cout<<"\n test for get back"<<endl;
    try{
        cout<<cL1.back()<<endl;
    }catch(ListEmpty e){
        cout<<e.what()<<endl;
    }

    cout<<"\n test for pop front"<<endl;
    try{
        cL1.pop_front();
    }catch(ListEmpty e){
        cout<<e.what();
    }

    cout<<"\n test for push back "<<endl;
    for(int i = 97 ; i< 107 ; i++){
        cL1.push_back(i);
    }
    cL1.display();
    cout<<"\n test for push front "<<endl;
    for(int i = 97; i< 117 ; i++){
        cL1.push_front(i);
    }
    cL1.display();

    cout<<"\n test for remove duplicate "<<endl;
    cL1.remove_duplicates();
    cL1.display();

    cout<<"\n test for sort"<<endl;
    cL1.select_sort();
    cL1.display();

    cout<<"\n test for insert a char at back"<<endl;
    cL1.insert_sorted(112);
    cL1.display();
    cout<<"\n test for insert a char at front"<<endl;
    cL1.insert_sorted(96);
    cL1.display();
    cout<<"\n test for insert a char at middle"<<endl;
    cL1.insert_sorted(115);
    cL1.display();

    LinkedList<char> cL2(cL1);
    cout<<"\n test for assign constructor "<<endl;
    cL2.display();
    cout<<"\n test for assign operator "<<endl;
    LinkedList<char> cL3;
    cL3 = cL2;
    cL3.display();


    cout<<"\n get front and pop front"<<endl;

        for(int i = 0 ;i < 25 ; i ++){
         try{
            cout<<i<<"   "<<cL1.front()<<endl;
            cL1.pop_front();
           }catch(ListEmpty e){
                cout<<e.what()<<endl;
           }
        }

   //////////////////////Test for String//////////////////
    cout<<"\n***************STRING************"<<endl;
    LinkedList<string> sL1;
    cout<<"Test for push back and front"<<endl;
    sL1.push_back("What's up");
    sL1.push_front("Dude");
    sL1.display();
    cout<<"\n Test for sort string"<<endl;
    sL1.select_sort();
    sL1.display();

    cout<<"\n Test for insert Sort"<<endl;
    sL1.insert_sorted("Whet's up");
    sL1.display();

    cout<<"\nSort String"<<endl;
    sL1.select_sort();
    sL1.display();

    cout<<"\nAdd duplicate and remove "<<endl;
    sL1.push_back("Dude");
    sL1.display();
    cout<<endl;
    sL1.remove_duplicates();
    sL1.display();
    cout<<endl;
    return 0;
}
