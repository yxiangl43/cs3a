#ifndef LISTEMPTY_H
#define LISTEMPTY_H
#include <iostream>
#include <string>
using namespace std;
/**************************************************************************
* class -  ListEmpty
*************************************************************************/
class ListEmpty{
private :
    //DATA TABlE
    string message;         //String
public :
/**************************************************************************
 * FUNCTION - ListEmpty
 *  Default constructor assign the message to list is empty
 *************************************************************************/
    ListEmpty(){ message ="List is empty";}
/**************************************************************************
 * FUNCTION - ListEmpty
 *  Default constructor assign the message as the string that passed in
 *************************************************************************/
    ListEmpty(string s){message = s;}
/**************************************************************************
* FUNCTION - what
*  return  message
*************************************************************************/
    string what(){ return message ;  }
};

#endif // LISTEMPTY_H
