#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <iostream>
#include "listempty.h"
using namespace std;
/**************************************************************************
* Struct -  structure Node
*************************************************************************/
template<typename E>
struct Node{
    //DATA TABLE
    E data;                         //templemate variable
    Node *next;                     //Pointer to next
    // Inline constructor
    Node( E data ) : data(data), next(0) {}
};
/**************************************************************************
* Class -  class Linkedlist
*************************************************************************/
template<typename E>
class LinkedList{
private:
    //DATA TABLE
    Node<E>* head;              //Head pointer for node
    Node<E>* tail;              //Tail pointer for node
public:
/**************************************************************************
* Function -  default constructor
*   Default constructor
*************************************************************************/
    LinkedList();
/**************************************************************************
* Function -  assign constructor
*   assign the node front the source to this head and tail
*************************************************************************/
    LinkedList(const LinkedList& source);               //IN-linkedlist
/**************************************************************************
* Function -  de constructor
*   delete every node
*************************************************************************/
    ~LinkedList();
/**************************************************************************
* Function -  assign operator
*   the the value from the source to this head and tail
*************************************************************************/
    LinkedList & operator=( const LinkedList& source );   //IN-linkedlist
/**************************************************************************
* Function -  display function
*   display the data for linked list
*************************************************************************/
    void display() const;
/**************************************************************************
* Function - push front function
*   add a value to the front of the list
*************************************************************************/
    void push_front( const E& value );              //IN- templement value
/**************************************************************************
* Function - push back function
*   add a value to the back of the list
*************************************************************************/
    void push_back( const E& value );               //IN- templement value
/**************************************************************************
* Function - pop front function
*   delete a value from the front of the list
*************************************************************************/
    void pop_front() throw(ListEmpty);
/**************************************************************************
* Function -  front function
*   return the value at the front of the list
*************************************************************************/
    const E& front() const throw(ListEmpty);          //throw exception
/**************************************************************************
* Function -  back function
*   return the value at the back of the list
*************************************************************************/
    const E& back() const throw(ListEmpty);          //throw exception
/**************************************************************************
* Function -  select_sort function
*   using the selection sort to sort the list
*************************************************************************/
    void select_sort();
/**************************************************************************
* Function -  insert_sorted function
*   adding a value to the list which has sort already
*************************************************************************/
    void insert_sorted( const E& value );         //IN- templement value
/**************************************************************************
* Function -  remove_duplicates function
*   remove the value value from the list
*************************************************************************/
    void remove_duplicates();
/**************************************************************************
* Function -  isEmpty function
*   check the list is empty or not
*************************************************************************/
    bool isEmpty() const;

};

/**************************************************************************
* FUNCTION -LinkedList
*_________________________________________________________________________
* Description
*   the default constructor the linked list. It sets the head and tail
* to null
* ________________________________________________________________________
* PRE-CONDITIONS
*   nothing
*
* POST-CONDITIONS
*   default setting
*************************************************************************/
template<typename E>
LinkedList<E>::LinkedList(){
    //PROCESS: sets head and tail both to null
    tail = NULL;
    head = tail;
}
/**************************************************************************
* FUNCTION -LinkedList
*_________________________________________________________________________
* Description
*   the assign constructor for the linked list. It assgin the value from
* another linked list to this linked list
* ________________________________________________________________________
* PRE-CONDITIONS
*   sour    :   a linked list
*
* POST-CONDITIONS
*   default setting
*************************************************************************/
template<typename E>
LinkedList<E>::LinkedList(const LinkedList& sour){
    //Process : set head and tail to null
    head = NULL;
    tail = NULL;
    //PROCESS : assign the value from the source to this list
    Node<E> * tempList = sour.head;
    for(Node<E> * i = tempList; i !=NULL; i = i->next){
        this->push_back(i->data);
    }
}
/**************************************************************************
* FUNCTION -LinkedList
*_________________________________________________________________________
* Description
*  This is the de constructor of the linked list. It delete the every node
* from the this linked list
* ________________________________________________________________________
* PRE-CONDITIONS
*
*
* POST-CONDITIONS
*   de constructor
*************************************************************************/
template<typename E>
LinkedList<E>::~LinkedList(){
    //PROCESS: delete every node in the list
    Node<E> * temp = NULL;
    while(head != NULL){
        temp = head->next;
        head = temp;
    }
    delete  temp;
}
/**************************************************************************
* FUNCTION -operator=
*_________________________________________________________________________
* Description
*  This is the assign a deep of the value from the source to this linked
* list
* ________________________________________________________________________
* PRE-CONDITIONS
*   source  :   linked list
*
* POST-CONDITIONS
*   return a linked list
*************************************************************************/
template<typename E>
LinkedList<E> & LinkedList<E>::operator =(const LinkedList& source ){
    //PROCESS: assign the value from the source to this
    Node<E> * tempList = source.head;
    for(Node<E> * i = tempList; i !=NULL; i = i->next){
        this->push_back(i->data);
    }
    return *this;
}
/**************************************************************************
* FUNCTION -front
*_________________________________________________________________________
* Description
*  It get the front end note from the list.If there is no Node at front from
* the list, it throw an exception
* ________________________________________________________________________
* PRE-CONDITIONS
*
*
* POST-CONDITIONS
*   return a value or throw an exception
*************************************************************************/
template<typename E>
const E& LinkedList<E>::front() const throw(ListEmpty){
        //PROCESS: list is empty throw the exception
        if(isEmpty()==true)
            throw ListEmpty();
        // list is not empty return the front value
        return head->data;

}
/**************************************************************************
* FUNCTION -back
*_________________________________________________________________________
* Description
*  It get the back end note from the list.If there is no Node at back from
* the list, it throw an exception
* ________________________________________________________________________
* PRE-CONDITIONS
*
*
* POST-CONDITIONS
*   return a value or throw an exception
*************************************************************************/
template<typename E>
const E& LinkedList<E>::back() const throw(ListEmpty){
    //PROCESS: list is empty throw the exception
        if(isEmpty()==true) {
               throw ListEmpty();
            }
         // list is not empty return the back value
        return tail->data;
}
/**************************************************************************
* FUNCTION -display
*_________________________________________________________________________
* Description
*  It display every value of the node in this linked list
* ________________________________________________________________________
* PRE-CONDITIONS
*
*
* POST-CONDITIONS
*   display the values
*************************************************************************/
template<typename E>
void LinkedList<E>::display() const{
    for(Node<E>* temp = head; temp!=NULL; temp = temp->next){
        cout<<temp->data<<" ";
    }
}
/**************************************************************************
* FUNCTION -isEmpty
*_________________________________________________________________________
* Description
*  It check the list is empty or not
* ________________________________________________________________________
* PRE-CONDITIONS
*
*
* POST-CONDITIONS
*   return true if list is empty ,otherwise return false
*************************************************************************/
template<typename E>
bool LinkedList<E>::isEmpty( )const{
    //RROCESS check the head and tail are null or not
    if(head == NULL && tail == NULL){
        return true;
    }
    return false;
}
/**************************************************************************
* FUNCTION -push_back
*_________________________________________________________________________
* Description
*  This function adds a node to the back end of the list
* ________________________________________________________________________
* PRE-CONDITIONS
*   value   :   Templeate value
*
* POST-CONDITIONS
*   adding one more node the list
*************************************************************************/
template<typename E>
void LinkedList<E>::push_back( const E& value ){
    //PROCESS: add the node to back of the list in cases
    Node<E>* temp = new Node<E>(value);
    if(isEmpty()==true){
        tail = temp;
        head =tail;
    }else{
        tail->next = temp;
        tail = tail->next;
    }

}
/**************************************************************************
* FUNCTION -push_front
*_________________________________________________________________________
* Description
*  This function adds a node to the front end of the list
* ________________________________________________________________________
* PRE-CONDITIONS
*   value   :   Templeate value
*
* POST-CONDITIONS
*   adding one more node the list
*************************************************************************/
template<typename E>
void LinkedList<E>::push_front( const E& value ){
   //PROCESS: add the node to the front of the list in cases
    Node<E>* temp = new Node<E>(value);
    if(head == NULL || tail == NULL)
    {
        head = temp;
        tail = head;
    }else{
        temp->next = head;
        head = temp;
    }

}
/**************************************************************************
* FUNCTION -pop_front
*_________________________________________________________________________
* Description
*  This function deletes a node from the front end of the list. If the list
* is empty, it throw an exception
* ________________________________________________________________________
* PRE-CONDITIONS
*
* POST-CONDITIONS
*   deleting a node from the list
*************************************************************************/
template<typename E>
void LinkedList<E>::pop_front() throw(ListEmpty){
    //PROCESS: if list is empty throw and exception
    if(isEmpty()){
        throw ListEmpty();
    }
    //PROCESS: delete a node from the front of the list
    Node<E>* temp = head->next;
    if(temp == NULL){
        head = NULL;
        tail = NULL;
    }else{
        delete head;
        head = temp;
    }

}

/**************************************************************************
* FUNCTION -select_sort
*_________________________________________________________________________
* Description
*  This function sorts the list by the selection sort
* ________________________________________________________________________
* PRE-CONDITIONS
*
* POST-CONDITIONS
*   sort the list
*************************************************************************/
template<typename E>
void LinkedList<E>::select_sort( ){
    //PROCESS: Nest for loop
    for(Node<E>* tempHead = head; tempHead != NULL; tempHead = tempHead->next){
        //Create a node for the current head
        Node<E>* selectNode = tempHead;

        for(Node<E>* tempCheck = tempHead->next; tempCheck!=NULL; tempCheck = tempCheck->next){
        //Check the data is same or not
            if(tempCheck->data < selectNode->data){
                selectNode= tempCheck;
            }
        }
        //Swap the value
        E tempDate = tempHead->data;
        tempHead->data = selectNode->data;
        selectNode->data = tempDate;
    }
}
/**************************************************************************
* FUNCTION -select_sort
*_________________________________________________________________________
* Description
*  This function assums the list is sorted already. It adding a new node
*  to the list
* ________________________________________________________________________
* PRE-CONDITIONS
*
* POST-CONDITIONS
*  adding a new node to the list
*************************************************************************/
template<typename E>
void LinkedList<E>::insert_sorted( const E& value ){
    //Create a tempHead for head
    Node<E> * tempHead = head;

   //while temphead is not null and the value for the temphead is less than
   //the value that passed in
    while(tempHead != NULL && tempHead->data < value){
        tempHead = tempHead->next;
    }

    //Check three cases for the value

    //value is the smallest
    if(tempHead == head){
        push_front(value);
    }
    //value is biggst
    else if(tempHead == NULL){
        push_back(value);
    }
    //value is at middle of the list
    else{
        Node<E> * temp = new Node<E>(value);
        temp->next = tempHead->next;
        tempHead->next = temp;
    }


}
/**************************************************************************
* FUNCTION -remove_duplicates
*_________________________________________________________________________
* Description
*  This function removes the duplicate value from the list
* ________________________________________________________________________
* PRE-CONDITIONS
*
* POST-CONDITIONS
*  remove the duplicate
*************************************************************************/
template<typename E>
void LinkedList<E>::remove_duplicates(){
    //create three node
    Node<E> * removeNode;
    Node<E> * tempHead = head;
    Node<E> * checkNode;

    //check tempHead is not Null
    while(tempHead!=NULL){
        //check node is the next node of the tempHead
        checkNode = tempHead->next;
        //removeNode is the temphead
        removeNode = tempHead;

        //check the checknode is not null
        while(checkNode!=NULL){

            //Find the value
            if(checkNode->data == tempHead->data){
                //let remove node be the previous node for the checknode
                while(removeNode->next != checkNode){
                    removeNode = removeNode->next;
                }
                //if next node of the check node is null
                //sets the next node for remove is null
                if(checkNode->next == NULL){
                    removeNode->next = NULL;
                    tail = removeNode;
                }
                //set next Node of  remove is the next node of the checknode
                else{
                    removeNode->next = checkNode->next;
                }

            }
            checkNode = checkNode->next;
        }

        tempHead = tempHead->next;
    }
}
#endif // LINKEDLIST_H
